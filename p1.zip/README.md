# CS3300P1
Static data visualization in JavasScript and D3, for the leading causes of death across the age groups in the United States.
